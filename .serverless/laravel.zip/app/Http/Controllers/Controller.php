<?php

namespace App\Http\Controllers;

/**
* @OA\Info(
*     version="1.0",
*     title="ShortenerUrl API Restfull"
* )
*/
abstract class Controller
{
    //
}
