import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState, useEffect, useMemo } from "react";
import { c as cn, I as IconButton } from "./IconButton-DnfZLqE_.js";
import { A as Authenticated } from "./AuthenticatedLayout-CGl_Z7Fe.js";
import { PlusIcon, PencilSquareIcon, TrashIcon } from "@heroicons/react/24/outline";
import { router, Head } from "@inertiajs/react";
import "clsx";
import "tailwind-merge";
import "./ApplicationLogo-VXSMMN2A.js";
import "@headlessui/react";
function ModalConfirm({ open, onConfirm, onClose }) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      id: "popup-modal",
      tabIndex: -1,
      className: cn("overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 flex justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full", open ? "bg-gray-900/50" : "hidden"),
      children: /* @__PURE__ */ jsx("div", { className: "relative p-4 w-full max-w-md max-h-full", children: /* @__PURE__ */ jsxs("div", { className: "relative bg-white rounded-lg shadow dark:bg-gray-700", children: [
        /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            className: "absolute top-3 end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white",
            "data-modal-hide": "popup-modal",
            onClick: onClose,
            children: [
              /* @__PURE__ */ jsx(
                "svg",
                {
                  className: "w-3 h-3",
                  "aria-hidden": "true",
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  viewBox: "0 0 14 14",
                  children: /* @__PURE__ */ jsx(
                    "path",
                    {
                      stroke: "currentColor",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "2",
                      d: "m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                    }
                  )
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Close modal" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "p-4 md:p-5 text-center", children: [
          /* @__PURE__ */ jsx(
            "svg",
            {
              className: "mx-auto mb-4 text-gray-400 w-12 h-12 dark:text-gray-200",
              "aria-hidden": "true",
              xmlns: "http://www.w3.org/2000/svg",
              fill: "none",
              viewBox: "0 0 20 20",
              children: /* @__PURE__ */ jsx(
                "path",
                {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                }
              )
            }
          ),
          /* @__PURE__ */ jsx("h3", { className: "mb-5 text-lg font-normal text-gray-500 dark:text-gray-400", children: "Are you sure you want to delete?" }),
          /* @__PURE__ */ jsx(
            "button",
            {
              "data-modal-hide": "popup-modal",
              type: "button",
              className: "text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center",
              onClick: onConfirm,
              children: "Yes, I'm sure"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              "data-modal-hide": "popup-modal",
              type: "button",
              className: "py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700",
              onClick: onClose,
              children: "No, cancel"
            }
          )
        ] })
      ] }) })
    }
  );
}
function TableBody({ columns: columns2, rows, onClickItem }) {
  const renderColumn = (row) => ({ id, prefix, suffix }, index) => /* @__PURE__ */ jsxs("th", { className: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white text-ellipsis overflow-hidden max-w-96", children: [
    prefix,
    row[id],
    suffix
  ] }, index);
  const renderRow = (row, index) => /* @__PURE__ */ jsx("tr", { className: "cursor-pointer bg-white border-b dark:bg-gray-800 dark:border-gray-700", onClick: () => onClickItem == null ? void 0 : onClickItem.call(null, row), children: columns2.map(renderColumn(row)) }, index);
  return /* @__PURE__ */ jsx("tbody", { children: rows.map(renderRow) });
}
function TableHead({ columns: columns2 }) {
  const renderColumn = ({ label }, index) => /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: label }, index);
  return /* @__PURE__ */ jsx("thead", { className: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400", children: /* @__PURE__ */ jsx("tr", { children: columns2.map(renderColumn) }) });
}
function TablePagination({
  total,
  page,
  perPage,
  hasMorePages,
  setPage,
  onNext,
  onPrevious
}) {
  const renderPage = (_page) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
    "button",
    {
      className: cn("flex items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white", _page === page ? "bg-gray-100" : ""),
      onClick: () => setPage == null ? void 0 : setPage.call(null, _page),
      children: _page
    }
  ) }, _page);
  const pages = Array.from(
    { length: Math.ceil(total / perPage) },
    (_, index) => index + 1
  );
  const disabledPreviuosBtn = page === 1;
  const disabledNextBtn = !hasMorePages;
  return /* @__PURE__ */ jsxs(
    "nav",
    {
      className: "flex items-center flex-column flex-wrap md:flex-row justify-between py-2 px-6",
      "aria-label": "Table navigation",
      children: [
        /* @__PURE__ */ jsxs("span", { className: "text-sm font-normal text-gray-500 dark:text-gray-400 mb-4 md:mb-0 block w-full md:inline md:w-auto", children: [
          "Showing",
          " ",
          /* @__PURE__ */ jsxs("span", { className: "font-semibold text-gray-900 dark:text-white", children: [
            page > 1 ? page - 1 + perPage : page,
            "-",
            page * perPage
          ] }),
          " ",
          "of",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-semibold text-gray-900 dark:text-white", children: total })
        ] }),
        /* @__PURE__ */ jsxs("ul", { className: "inline-flex -space-x-px rtl:space-x-reverse text-sm h-8", children: [
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
            "button",
            {
              className: "flex items-center justify-center px-3 h-8 ms-0 leading-tight text-gray-500 bg-white border border-gray-300 rounded-s-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white",
              onClick: onPrevious,
              disabled: disabledPreviuosBtn,
              children: "Previous"
            }
          ) }),
          pages.map(renderPage),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
            "button",
            {
              className: "flex items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 rounded-e-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white",
              onClick: onNext,
              disabled: disabledNextBtn,
              children: "Next"
            }
          ) })
        ] })
      ]
    }
  );
}
function Table({
  columns: columns2,
  rows,
  onClickItem,
  page,
  perPage,
  total,
  hasMorePages,
  setPage,
  onNext,
  onPrevious
}) {
  return /* @__PURE__ */ jsxs("div", { className: "relative overflow-x-auto shadow-md sm:rounded-lg", children: [
    /* @__PURE__ */ jsxs("table", { className: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400", children: [
      /* @__PURE__ */ jsx(TableHead, { columns: columns2 }),
      /* @__PURE__ */ jsx(TableBody, { columns: columns2, rows, onClickItem })
    ] }),
    /* @__PURE__ */ jsx(
      TablePagination,
      {
        page,
        perPage,
        total,
        hasMorePages,
        setPage,
        onNext,
        onPrevious
      }
    )
  ] });
}
const columns = [
  {
    id: "id",
    label: "id"
  },
  {
    id: "code",
    label: "code"
  },
  {
    id: "title",
    label: "title"
  },
  {
    id: "original_url",
    label: "Original Url"
  },
  {
    id: "actions",
    label: "Actions"
  }
];
function ListShortenerURL({
  auth,
  domain,
  paginator
}) {
  const [rows, setRows] = useState(paginator.items);
  const [page, setPage] = useState(paginator.page);
  const [perPage, setPerPage] = useState(paginator.perPage);
  const [hasMorePages, setHasMorePages] = useState(paginator.hasMorePages);
  const [total, setTotal] = useState(paginator.total);
  const [remove, setRemove] = useState(null);
  useEffect(() => {
    if (page === paginator.page) return;
    router.get(route("shortenerUrl.index", { page }));
  }, [page]);
  const handleRemove = () => {
    router.delete(route("shortenerUrl.destroy", remove), {
      preserveState: false
    });
  };
  const onRemove = (id) => (event) => {
    event.stopPropagation();
    setRemove(id);
  };
  const onSetPage = (page2) => {
    setPage(page2);
  };
  const onNext = () => {
    setPage(page + 1);
  };
  const onPrevious = () => {
    setPage(page - 1);
  };
  const parserData = (item) => {
    const { id, code, title, original_url } = item;
    return {
      id,
      code,
      title,
      original_url,
      actions: /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(
          IconButton,
          {
            icon: /* @__PURE__ */ jsx(PencilSquareIcon, { className: "size-4" }),
            "aria-label": "Edit a shortener url",
            className: "text-blue-700 hover:text-white border-blue-700 hover:bg-blue-800 focus:ring-blue-300 dark:border-blue-500 dark:text-blue-500 dark:hover:text-white dark:hover:bg-blue-500 dark:focus:ring-blue-800",
            onClick: (event) => {
              event.stopPropagation();
              router.visit(route("shortenerUrl.show", id));
            }
          }
        ),
        /* @__PURE__ */ jsx(
          IconButton,
          {
            icon: /* @__PURE__ */ jsx(TrashIcon, { className: "size-4" }),
            "aria-label": "Remove a shortened url",
            className: "text-white bg-red-700 hover:bg-red-800 focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900",
            onClick: onRemove(id)
          }
        )
      ] })
    };
  };
  const visibleRows = useMemo(
    () => rows.map(parserData),
    [rows, page, perPage]
  );
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      breadcrumbs: [
        {
          href: route("shortenerUrl.index"),
          label: "List shortener urls"
        }
      ],
      header: /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight", children: "Shortened URLs" }),
        /* @__PURE__ */ jsx(
          IconButton,
          {
            href: route("shortenerUrl.create"),
            icon: /* @__PURE__ */ jsx(PlusIcon, { className: "size-4" }),
            "aria-label": "Create new a shortened url",
            className: "text-gray-900 bg-white border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "List - Shortener Url" }),
        /* @__PURE__ */ jsx(
          Table,
          {
            columns,
            rows: visibleRows,
            page,
            perPage,
            total,
            hasMorePages,
            setPage: onSetPage,
            onNext,
            onPrevious,
            onClickItem: (row) => window.open(route("shortenerUrl.link", row.code))
          }
        ),
        /* @__PURE__ */ jsx(
          ModalConfirm,
          {
            open: Boolean(remove),
            onClose: () => setRemove(null),
            onConfirm: handleRemove
          }
        )
      ]
    }
  );
}
export {
  ListShortenerURL as default
};
