import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { I as IconButton } from "./IconButton-DnfZLqE_.js";
import { T as TextInput, I as InputError } from "./TextInput-CKZWVcbn.js";
import { I as InputLabel } from "./InputLabel-BEr_TVw9.js";
import { A as Authenticated } from "./AuthenticatedLayout-CGl_Z7Fe.js";
import { CheckIcon } from "@heroicons/react/24/outline";
import { useForm, Head } from "@inertiajs/react";
import { useRef } from "react";
import "clsx";
import "tailwind-merge";
import "./ApplicationLogo-VXSMMN2A.js";
import "@headlessui/react";
function CreateShortenerURL({ auth }) {
  const btnRef = useRef(null);
  const { data, setData, post, processing, errors, reset } = useForm({
    title: "",
    original_url: ""
  });
  const handlerChange = (field) => (event) => setData(field, event.target.value);
  const submit = (e) => {
    e.preventDefault();
    post(route("shortenerUrl.store"), {
      onFinish: () => reset("title", "original_url")
    });
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      breadcrumbs: [
        {
          href: route("shortenerUrl.index"),
          label: "List shortener urls"
        },
        {
          href: route("shortenerUrl.create"),
          label: "Edit shortener url"
        }
      ],
      header: /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight", children: "Create - Shortened URLs" }),
        /* @__PURE__ */ jsx(
          IconButton,
          {
            icon: /* @__PURE__ */ jsx(CheckIcon, { className: "size-4" }),
            "aria-label": "Save",
            className: "text-gray-900 bg-white border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700",
            onClick: () => {
              var _a;
              return (_a = btnRef.current) == null ? void 0 : _a.click();
            },
            disabled: processing
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Create - Shortener Url" }),
        /* @__PURE__ */ jsx("div", { className: "w-full px-6 py-6 bg-white dark:bg-gray-800 shadow-md overflow-hidden sm:rounded-lg", children: /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(InputLabel, { htmlFor: "title", value: "Title" }),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "title",
                name: "title",
                value: data.title,
                className: "mt-1 block w-full",
                isFocused: true,
                onChange: handlerChange("title"),
                required: true
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.title, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-4", children: [
            /* @__PURE__ */ jsx(InputLabel, { htmlFor: "original_url", value: "Original Url" }),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "original_url",
                name: "original_url",
                type: "url",
                value: data.original_url,
                className: "mt-1 block w-full",
                onChange: handlerChange("original_url"),
                required: true
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.original_url, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsx("button", { ref: btnRef, type: "submit", className: "hidden" })
        ] }) })
      ]
    }
  );
}
export {
  CreateShortenerURL as default
};
