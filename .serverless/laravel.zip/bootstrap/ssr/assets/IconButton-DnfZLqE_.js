import { jsxs, jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Link } from "@inertiajs/react";
const cn = (...inputs) => {
  return twMerge(clsx(inputs));
};
const defaultClassNames = [
  "border",
  "focus:ring-4",
  "focus:outline-none",
  "font-medium",
  "rounded-lg",
  "text-sm",
  "p-2.5",
  "text-center",
  "inline-flex",
  "items-center",
  "me-2"
];
function IconButton({
  href,
  method,
  className = "",
  disabled,
  icon,
  color,
  ...props
}) {
  return href ? /* @__PURE__ */ jsxs(
    Link,
    {
      href,
      method,
      as: "button",
      className: cn(className, defaultClassNames),
      "aria-label": props["aria-label"],
      disabled,
      children: [
        icon,
        props["aria-label"] && /* @__PURE__ */ jsx("span", { className: "sr-only", children: props["aria-label"] })
      ]
    }
  ) : /* @__PURE__ */ jsxs(
    "button",
    {
      className: cn(className, defaultClassNames),
      onClick: props.onClick,
      "aria-label": props["aria-label"],
      disabled,
      children: [
        icon,
        props["aria-label"] && /* @__PURE__ */ jsx("span", { className: "sr-only", children: props["aria-label"] })
      ]
    }
  );
}
export {
  IconButton as I,
  cn as c
};
